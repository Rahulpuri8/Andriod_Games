# potato-head-game-android-kotlin
Design of a potato by adding multiple things over it, i.e.,
1. eyes
2. ears
3. nose
4. mouth
5. shoes
6. arms
7. hat
8. etc
# using checkbox and its listener
using checkbox for the options to be applied on the potato and 

its action listener to hide and unhide the images.

# Screenshot:
![screenshot](https://github.com/abdulwaheedchachar/potato-head-game-android-kotlin/blob/master/screenshot.png)
