# GuessNumberGame-Android-Kotlin

my first andoid app

guess the number game

build in andoid studio

using kotlin language

# screenshot of application
![screenshot](https://github.com/abdulwaheedchachar/GuessNumberGame-Android-Kotlin/blob/master/screenshot.png)
